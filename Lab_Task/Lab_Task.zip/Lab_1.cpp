#include<iostream>
//#include<stdio.h>
using namespace std;
int main()
{

 /*   char s[30];
    int a;
    //gets(s);
    scanf("%d",&a);
    getchar();
    gets(s);
   // std::cout<<"Hello World!\n";
    //printf("Hello World!\n");
    printf("My Name is %s",s);
    printf(", Roll %d\n",a);
    */

   /* string name2;
    int roll2;
    cin>>roll2;
    cin.ignore();
    getline(cin,name2);
    for(int i=1;i<=100000;i++)

    cout<<"My name is "<<name2<<",Roll = "<<roll2<<endl;

*/
 /*  int roll[10];
   char name[10][50];
   for(int i=0;i<3;i++)
   {
   scanf("%d",&roll[i]);
   getchar();
   gets(name[i]);
   }
   printf("-----------------------------\n");
   printf("|NAME         |ROLL         |\n");
   for(int i=0;i<3;i++)
   {
       printf("-----------------------------\n");
       printf("|%s          |%d             |\n",name[i],roll[i]);
   }

   //printf("My Name is %s and Roll %d\n",name,roll);
    */

